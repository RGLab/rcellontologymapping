# rcellontologymapping
R interface to generate leukocyte cell classifications from cell surface markers using the decision tree from Maecker et al. (2012)
